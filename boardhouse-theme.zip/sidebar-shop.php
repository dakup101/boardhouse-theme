<div class="sidebar">
	<?php dynamic_sidebar('sidebar-shop'); ?>
</div>