<section class="mt-10">
	<?php get_template_part('/components/boardhouse-product-promo'); ?>
</section>
<section class="mt-10">
	<?php get_template_part('/components/boardhouse-cta'); ?>
</section>
<section class="my-28 container mx-auto">
	<?php get_template_part('/components/boardhouse-icons-row'); ?>
</section>


<footer class="bg-light-gray">
	<?php get_template_part('/components/boardhouse-footer'); ?>
	<?php wp_footer(); ?>
</footer>
</body>
</html>