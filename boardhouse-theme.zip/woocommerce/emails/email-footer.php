<?php defined( 'ABSPATH' ) || exit; ?>

</div>
<div style="max-width: 600px; display: block; margin: 0 auto; background-color: #212121;">
    <table style="color: white; width: 100%; text-align: left; table-layout: fixed;  padding: 25px">
		<thead style="font-size: 16px">
			<tr>
				<th>Dane Kontaktowe</th>
				<th>Sklep</th>
				<th>Informacje</th>
			</tr>
		</thead>
		<tbody style="font-size: 13px;">
			<tr >
				<td style="padding-top: 20px;"><strong>Boardhouse</strong></td>
				<td style="padding-top: 20px;">Deski</td>
				<td style="padding-top: 20px;">Dostawa</td>
			</tr>
			<tr>
				<td>ul. Malborska 96</td>
				<td>Buty</td>
				<td>Zwroty i wymiana</td>
			</tr>
			<tr>
				<td>30-624 Kraków</td>
				<td>Wiązania</td>
				<td>Płatności</td>
			</tr>
			<tr>
				<td></td>
				<td>Hulajnogi</td>
				<td>Reklamacje</td>
			</tr>
			<tr>
				<td>biuro@boardhouse.pl</td>
				<td>Longboardy</td>
				<td>Regulamin sklepu</td>
			</tr>
			<tr>
				<td>+48 693 081 786</td>
				<td>Rolki</td>
				<td>Polityka Prywatności</td>
			</tr>
			
			<tr>
				<td></td>
				<td>Wrotki</td>
				<td></td>
			</tr>
		</tbody>
	</table>
</div>

</body>
</html>