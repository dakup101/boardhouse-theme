<footer class="bg-light-gray">
    <?php get_template_part('/components/boardhouse-footer'); ?>
    <?php wp_footer(); ?>
</footer>
</body>
</html>