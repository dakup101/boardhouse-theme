<header>
    <?php get_template_part('components/header/boardhouse-top-bar'); ?>
    <?php get_template_part('components/header/boardhouse-nav'); ?>
</header>