<?php
register_nav_menus(array(
    'primary' => esc_html__('Główne', 'boardhouse-theme'),
));