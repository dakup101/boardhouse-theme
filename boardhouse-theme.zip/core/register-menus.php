<?php
register_nav_menus(array(
    'primary' => esc_html__('Główne', 'boardhouse-theme'),
    'mobile' => esc_html__('Mobilne', 'boardhouse-theme'),
    'footer-1' => esc_html__('Stopka (Kolumna 1)', 'boardhouse-theme'),
    'footer-2' => esc_html__('Stopka (Kolumna 2)', 'boardhouse-theme'),
    'footer-3' => esc_html__('Stopka (kolumna 3)', 'boardhouse-theme'),
));