<?php
remove_action( 'woocommerce_checkout_order_review', 'woocommerce_checkout_payment', 20 );

